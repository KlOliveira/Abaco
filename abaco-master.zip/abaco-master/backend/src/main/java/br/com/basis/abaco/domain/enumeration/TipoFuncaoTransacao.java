package br.com.basis.abaco.domain.enumeration;

/**
 * The TipoFuncaoTransacao enumeration.
 */
public enum TipoFuncaoTransacao {
    EE, SE, CE, INM
}
