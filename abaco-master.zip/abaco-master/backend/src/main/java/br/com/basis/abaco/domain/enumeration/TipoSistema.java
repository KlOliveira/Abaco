package br.com.basis.abaco.domain.enumeration;

/**
 * The TipoSistema enumeration.
 */
public enum TipoSistema {
    NOVO, LEGADO
}
