/**
 * Spring Data JPA repositories.
 */
package br.com.basis.abaco.repository;
