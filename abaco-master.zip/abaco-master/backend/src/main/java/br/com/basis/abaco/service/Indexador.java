package br.com.basis.abaco.service;

public interface Indexador {

    void indexar();

    String getCodigo();

    void setCodigo(String codigo);

    String getDescricao();

    void setDescricao(String descricao);


}
