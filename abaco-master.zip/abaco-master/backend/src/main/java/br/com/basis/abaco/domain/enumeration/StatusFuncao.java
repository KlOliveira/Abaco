package br.com.basis.abaco.domain.enumeration;

/**
 * The ImpactoFatorAjuste enumeration.
 */
public enum StatusFuncao {
    DIVERGENTE, EXCLUIDO, VALIDADO,
}
