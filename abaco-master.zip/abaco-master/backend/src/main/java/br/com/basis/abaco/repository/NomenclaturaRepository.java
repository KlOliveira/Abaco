package br.com.basis.abaco.repository;

import br.com.basis.abaco.domain.Nomenclatura;
import org.springframework.data.jpa.repository.JpaRepository;

public interface NomenclaturaRepository extends JpaRepository<Nomenclatura, Long> {

}
