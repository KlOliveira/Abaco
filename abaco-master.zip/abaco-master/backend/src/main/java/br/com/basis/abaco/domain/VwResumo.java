package br.com.basis.abaco.domain;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "vw_resumo")
public class VwResumo extends VwResumoBase {

}
