package br.com.basis.abaco.domain.enumeration;

/**
 * The MetodoContagem enumeration.
 */
public enum MetodoContagem {
    DETALHADA,INDICATIVA,ESTIMADA
}
