package br.com.basis.abaco.domain.enumeration;

/**
 * The Complexidade enumeration.
 */
public enum Complexidade {
    SEM, BAIXA, MEDIA, ALTA
}
