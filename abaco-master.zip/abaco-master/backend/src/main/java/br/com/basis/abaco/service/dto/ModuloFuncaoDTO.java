package br.com.basis.abaco.service.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ModuloFuncaoDTO {

    private Long id;

    private String nome;
}
