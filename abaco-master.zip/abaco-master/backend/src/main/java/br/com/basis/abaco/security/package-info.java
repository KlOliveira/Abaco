/**
 * Spring Security configuration.
 */
package br.com.basis.abaco.security;
