/**
 * View Models used by Spring MVC REST controllers.
 */
package br.com.basis.abaco.web.rest.vm;
