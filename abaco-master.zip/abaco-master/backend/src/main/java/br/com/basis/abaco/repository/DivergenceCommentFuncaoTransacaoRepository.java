package br.com.basis.abaco.repository;

import br.com.basis.abaco.domain.DivergenceCommentFuncaoTransacao;
import org.springframework.data.jpa.repository.JpaRepository;

public interface  DivergenceCommentFuncaoTransacaoRepository extends JpaRepository<DivergenceCommentFuncaoTransacao, Long> {

}
