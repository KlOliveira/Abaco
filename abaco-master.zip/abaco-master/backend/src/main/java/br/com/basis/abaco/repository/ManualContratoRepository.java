package br.com.basis.abaco.repository;

import br.com.basis.abaco.domain.ManualContrato;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ManualContratoRepository extends JpaRepository<ManualContrato, Long> {
}
