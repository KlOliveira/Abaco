/**
 * Data Transfer Objects.
 */
package br.com.basis.abaco.service.dto;
