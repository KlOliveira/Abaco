package br.com.basis.abaco.domain.enumeration;

/**
 * The TipoAnalise enumeration.
 */
public enum TipoAnalise {
    DESENVOLVIMENTO,MELHORIA,APLICACAO
}
