package br.com.basis.abaco.web.rest;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


/**
 * @author eduardo.andrade
 * @since 20/03/2018
 */
@RestController
@RequestMapping("/baseline")
public class BaselineResource {



}
