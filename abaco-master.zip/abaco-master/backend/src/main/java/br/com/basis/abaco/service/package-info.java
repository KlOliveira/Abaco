/**
 * Service layer beans.
 */
package br.com.basis.abaco.service;
