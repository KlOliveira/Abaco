package br.com.basis.abaco.domain.enumeration;

/**
 * The TipoFuncaoDados enumeration.
 */
public enum TipoFuncaoDados {
    ALI, AIE, INM
}
