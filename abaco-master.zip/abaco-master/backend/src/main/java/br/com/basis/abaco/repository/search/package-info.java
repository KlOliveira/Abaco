/**
 * Spring Data Elasticsearch repositories.
 */
package br.com.basis.abaco.repository.search;
