package br.com.basis.abaco.domain.enumeration;

/**
 * The ImpactoFatorAjuste enumeration.
 */
public enum ImpactoFatorAjuste {
    INCLUSAO, ALTERACAO, EXCLUSAO, CONVERSAO, ITENS_NAO_MENSURAVEIS
}
