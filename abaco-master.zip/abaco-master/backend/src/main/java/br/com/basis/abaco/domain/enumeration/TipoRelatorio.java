package br.com.basis.abaco.domain.enumeration;

/**
 * @author eduardo.andrade
 * @since 03/07/2018
 */
public enum TipoRelatorio {

    ANALISE, ANALISE_DETALHADA, BASELINE, CONTAGEM
}
