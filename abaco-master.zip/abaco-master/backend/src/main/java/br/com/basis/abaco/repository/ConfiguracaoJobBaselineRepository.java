package br.com.basis.abaco.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import br.com.basis.abaco.domain.ConfiguracaoJobBaseline;

public interface ConfiguracaoJobBaselineRepository extends JpaRepository<ConfiguracaoJobBaseline,Long>{

}
