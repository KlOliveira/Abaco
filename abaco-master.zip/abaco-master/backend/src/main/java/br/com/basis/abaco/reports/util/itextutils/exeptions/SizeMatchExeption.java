package br.com.basis.abaco.reports.util.itextutils.exeptions;

public class SizeMatchExeption extends RuntimeException {
    public SizeMatchExeption(String message) {
        super(message);
    }
}
