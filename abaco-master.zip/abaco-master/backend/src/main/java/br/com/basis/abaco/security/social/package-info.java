/**
 * Spring social configuration.
 */
package br.com.basis.abaco.security.social;
