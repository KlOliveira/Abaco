package br.com.basis.abaco.repository;

import br.com.basis.abaco.domain.DivergenceCommentFuncaoDados;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DivergenceCommentFuncaoDadosRepository extends JpaRepository<DivergenceCommentFuncaoDados, Long> {

}
