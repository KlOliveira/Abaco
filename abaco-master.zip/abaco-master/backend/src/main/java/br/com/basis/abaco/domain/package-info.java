/**
 * JPA domain objects.
 */
package br.com.basis.abaco.domain;
