package br.com.basis.abaco.domain.enumeration;

/**
 * The TipoFatorAjuste enumeration.
 */
public enum TipoFatorAjuste {
    PERCENTUAL, UNITARIO
}
